<?php

namespace Database\Factories;

use App\Models\student;
use Illuminate\Database\Eloquent\Factories\Factory;



class studentfactoryFactory extends Factory
{
    /**
     * The name of the factory's corresponding model.
     *
     * @var string
     */
    protected $model = student::class;

    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'studname'=>$this->faker->studname,
            'mobnum'=>$this->faker->mobnum,
            'statename'=>$this->faker->statename,
            'districtname'=>$this->faker->districtname,
            'cityname'=>$this->faker->cityname,
            'schoolname'=>$this->faker->schoolname,
            'classname'=>$this->faker->classname,
        ];
    }
}
