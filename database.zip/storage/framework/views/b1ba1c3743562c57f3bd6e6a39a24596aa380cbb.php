<html>
<head>
<title> Document</title>

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
 
   <body>
   <h1> Add Student Details</h1>
    <div class="container">
   <form id="myForm" action="<?php echo e(route('addstudent')); ?>" method="POST"enctype="multipart/form-data">
   <?php echo csrf_field(); ?>
  <div class="form-group">
    <label>Name</label>
    <input type="text" name="studname"class="form-control" value="">
      </div>
  <div class="form-group">
    <label>MobileNo.</label>
    <input type="integer" name="mobnum" class="form-control"  value="">
  </div>
  <div class="custom-file">
      <input type="file" name="filenames[]"class="custom-file-input">
    <label class="custom-file-label">Choose file</label>
  </div>

  <label>State Id</label>
  <div class="input-group mb-3">
  <select class="custom-select" id="inputGroupSelect02" name="state_id">
   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   {
      <option value="<?php echo e($val->id); ?>"><?php echo e($val->statename); ?></option>
  }
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
 </div>
 <label>District Id</label>
  <div class="input-group mb-3">
  <select class="custom-select" id="inputGroupSelect02" name="district_id">
   <?php $__currentLoopData = $data1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   {
      <option value="<?php echo e($val->id); ?>"><?php echo e($val->districtname); ?></option>
  }
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
 </div>
 <label>City Id</label>
  <div class="input-group mb-3">
  <select class="custom-select" id="inputGroupSelect02" name="city_id">
   <?php $__currentLoopData = $data2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   {
      <option value="<?php echo e($val->id); ?>"><?php echo e($val->cityname); ?></option>
  }
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
 </div>
 <label>School Id</label>
  <div class="input-group mb-3">
  <select class="custom-select" id="inputGroupSelect02" name="school_id">
   <?php $__currentLoopData = $data3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   {
      <option value="<?php echo e($val->id); ?>"><?php echo e($val->schoolname); ?></option>
  }
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
 </div>
 <label>Class Id</label>
  <div class="input-group mb-3">
  <select class="custom-select" id="inputGroupSelect02" name="class_id">
   <?php $__currentLoopData = $data4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   {
      <option value="<?php echo e($val->id); ?>"><?php echo e($val->classname); ?></option>
  }
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </select>
 </div>
  
     <div class="form-group">
    <label>Status</label>
    <input type="text"  name="status"class="form-control"value="">
      </div>
      
  <button type="submit" name="submit" class="btn btn-primary">Submit</button>
</form>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.js"></script>
<script>
$(document).ready(function(){
  $('#submit').click(function(e){
    e.preventDefault();
    $.ajax({
      url: "<?php echo e(url('addstudent')); ?>",
      type:"post",
      dataType:"json",
      data:$('#myForm').serialize(),
      success: function(response) {
        $('#myform') [0].reset();
        console.log(response);
      }
    });
  });
});
</script>
</body>
</html>

<?php /**PATH C:\xampp\htdocs\studentdb\resources\views/studentform.blade.php ENDPATH**/ ?>