<!doctype html>
<html lang="en">
  <head>
    <title>Student Details</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css" rel="stylesheet">
   
  </head>
  <body>

  <div class="container mt-5">
    <h3 class="text-center font-weight-bold">Student Details</h3>
    <table class="table mt-4" id="studentTable">
        <thead>
        <th>Student Name</th>
                <th>Mobile Number</th>
                <th>State Name</th>
                <th>District Name</th>
                <th>City  Name</th>
                <th>School  Name</th>
                <th>Class Name</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            @foreach($students as $item)
      <tr>
        <td>{{$item->studname}}</td>
        <td>{{$item->mobnum}}</td>
        <td>{{$item->statename}}</td>
        <td>{{$item->districtname}}</td>
        <td>{{$item->cityname}}</td>
        <td>{{$item->schoolname}}</td>
        <td>{{$item->classname}}</td>
        @endforeach
                       </tr>
             </tbody>
        <tfoot>
            <tr>
            <th>Student Name</th>
                <th>Mobile Number</th>
                <th>State Name</th>
                <th>District Name</th>
                <th>City  Name</th>
                <th>school  Name</th>
                <th>Class Name</th>
            </tr>
        </tfoot>
    </table>
     
</div>
      
  <script src="https://code.jquery.com/jquery-3.5.0.js" integrity="sha256-r/AaFHrszJtwpe+tHyNi/XCfMxYpbsRg2Uqn0x3s2zc=" crossorigin="anonymous"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
  <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

  <script type="text/javascript">
  
   $(document).ready(function() {
      var table = $('#studentTable').dataTable({
  // processing: true,
      serverSide: true,
      ajax: "{{ url('studentdetails') }}",
       
              "columns": [
      {data: "DT_RowIndex", name: "DT_RowIndex"},
    {data: "studname", name: "studname"},
    {data: "mobnum", name: "mobnum"},
     {data: "statename", name: "statename"},
     {data: "districtname", name: "districtname"},
     {data: "cityname", name: "cityname"},
     {data: "schoolname", name: "schoolname"},
     {data: "classname", name: "classname"},
        
]       
            });
        });
      </script>
   
     
</body>
</html>
