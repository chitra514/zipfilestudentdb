<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Details</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"  href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

</head>

  
 <body>
 <table id="#studenttbl" class="display" style="width:100%">
          <thead>
             <tr>
                <th>Student</th>
                <th>Mobile Number</th>
                <th>State Name</th>
                <th>District Name</th>
                <th>City  Name</th>
                <th>School  Name</th>
                <th>Class Name</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($item->studname); ?></td>
        <td><?php echo e($item->mobnum); ?></td>
        <td><?php echo e($item->statename); ?></td>
        <td><?php echo e($item->districtname); ?></td>
        <td><?php echo e($item->cityname); ?></td>
        <td><?php echo e($item->schoolname); ?></td>
        <td><?php echo e($item->classname); ?></td>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tr>
             </tbody>
        <tfoot>
            <tr>
            <th>Student Name</th>
                <th>Mobile Number</th>
                <th>State Name</th>
                <th>District Name</th>
                <th>City  Name</th>
                <th>school  Name</th>
                <th>Class Name</th>
            </tr>
        </tfoot>
    </table>
     
</div>
</body>
</html>
<script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready( function () {
    $('#studenttbl').dataTable();
} );
</script>
 
 <?php /**PATH C:\xampp\htdocs\studentdb\resources\views/studentdetails.blade.php ENDPATH**/ ?>