<!DOCTYPE html>
<html lang="en">
<head>
  <title>Student Details</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet"  href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

</head>

  
 <body>
 <table id="#studenttbl" class="display" style="width:100%">
          <thead>
             <tr>
                <th>Student</th>
                <th>Mobile Number</th>
                <th>State Name</th>
                <th>District Name</th>
                <th>City  Name</th>
                <th>School  Name</th>
                <th>Class Name</th>
            </tr>
        </thead>
        <tbody>
            <tr>
            @foreach($students as $item)
      <tr>
        <td>{{$item->studname}}</td>
        <td>{{$item->mobnum}}</td>
        <td>{{$item->statename}}</td>
        <td>{{$item->districtname}}</td>
        <td>{{$item->cityname}}</td>
        <td>{{$item->schoolname}}</td>
        <td>{{$item->classname}}</td>
        @endforeach
                       </tr>
             </tbody>
        <tfoot>
            <tr>
            <th>Student Name</th>
                <th>Mobile Number</th>
                <th>State Name</th>
                <th>District Name</th>
                <th>City  Name</th>
                <th>school  Name</th>
                <th>Class Name</th>
            </tr>
        </tfoot>
    </table>
     
</div>
</body>
</html>
<script src="//cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

<script>
$(document).ready( function () {
    $('#studenttbl').dataTable();
} );
</script>
 
 